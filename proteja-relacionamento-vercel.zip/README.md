# Proteja Seu Relacionamento — demonstração

Projeto estático em HTML, CSS e JavaScript, pronto para importar na Vercel.

## Arquivos
- `index.html`: página principal
- `style.css`: estilos
- `script.js`: interações
- `vercel.json`: configuração simples da Vercel

## Testar localmente
Abra `index.html` no navegador.

## Publicar na Vercel
1. Envie esta pasta para um repositório GitHub.
2. Na Vercel, escolha Add New → Project e importe o repositório.
3. Framework Preset: Other.
4. Build Command: deixe vazio.
5. Output Directory: `.` (raiz).
6. Clique Deploy.

Esta é apenas uma demonstração de contato consentido. Não monitora contas, não acessa WhatsApp, não obtém localização e não simula resultados reais de espionagem.
