const screens=[...document.querySelectorAll(".screen")];
function show(id){screens.forEach(s=>s.classList.toggle("active",s.id===id));window.scrollTo({top:0,behavior:"smooth"});}
let selectedKind="contato",fullNumber="";
document.querySelectorAll(".choice").forEach(btn=>btn.addEventListener("click",()=>{selectedKind=btn.dataset.kind;show("phone");}));
document.getElementById("backHome").addEventListener("click",()=>show("home"));
document.getElementById("phoneForm").addEventListener("submit",e=>{
 e.preventDefault();const local=document.getElementById("phoneNumber").value.replace(/\D/g,"");
 if(!/^9\d{8}$/.test(local)){alert("Digite um número angolano válido com 9 dígitos, começando por 9.");return;}
 fullNumber="244"+local;show("processing");
 const status=document.getElementById("status");status.textContent="Demonstração concluída. Nenhuma conta foi acessada.";
 setTimeout(()=>{document.getElementById("reportPhone").textContent="+"+fullNumber;show("report");},1000);
});
document.getElementById("whatsappBtn").addEventListener("click",()=>{
 const message=encodeURIComponent("Olá! Estou entrando em contato. Podemos conversar?");
 window.open("https://wa.me/"+fullNumber+"?text="+message,"_blank","noopener");
});
document.getElementById("restart").addEventListener("click",()=>{document.getElementById("phoneNumber").value="";show("home");});
document.getElementById("menuBtn").addEventListener("click",()=>document.getElementById("menuPanel").classList.remove("hidden"));
document.getElementById("closeMenu").addEventListener("click",()=>document.getElementById("menuPanel").classList.add("hidden"));
document.querySelectorAll('a[href="#home"]').forEach(a=>a.addEventListener("click",e=>{e.preventDefault();show("home");document.getElementById("menuPanel").classList.add("hidden");}));
